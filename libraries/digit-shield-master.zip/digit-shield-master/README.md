# Digit Shield Arduino Library

This library provides the API to control the output of the nootropic design Digit Shield. For all product
information and detailed API documentation, [see the Digit Shield product page](https://nootropicdesign.com/digitshield/).
